# 🎸 DoomBitcrusher

A professional-grade bitcrusher VST3 plugin built with JUCE.

## Features

- **Bit-depth reduction** (1-16 bits) - Recreate classic digital distortion
- **Sample rate reduction** - Aliasing and decimation effects
- **Drive/Saturation stage** - Add warmth before crushing
- **Wet/Dry mix** - Parallel processing support
- **Real-time visualizer** - See your signal being destroyed
- **Dithering option** - Smooth quantization noise

## Quick Start

### Windows

1. **Install prerequisites:**
   - Visual Studio 2022 (Community Edition)
   - CMake 3.20+
   - Git for Windows

2. **Build:**
   ```cmd
   build_windows.bat
   ```

3. **Install:**
   ```cmd
   install_windows.bat
   ```

4. **Use in your DAW:**
   - Rescan plugins
   - Look for "DoomBitcrusher" in VST3 plugins

### Linux

See the Linux build instructions in the main repository.

## Documentation

- [Windows Build Guide](WINDOWS_BUILD_INSTRUCTIONS.md) - Complete Windows setup
- [DESIGN.md](DESIGN.md) - Architecture and DSP specifications

## Plugin Controls

| Parameter | Description |
|-----------|-------------|
| Bit Depth | 1-16 bits of glorious destruction |
| Sample Rate | 1000Hz to 48kHz reduction |
| Mix | Blend between clean and crushed |
| Drive | Input saturation stage |
| Dither | Smooth quantization noise |

## Presets

- **Lo-Fi Tape** - Warm, nostalgic crunch
- **NES Style** - 8-bit console emulation
- **Radio** - AM radio bandwidth simulation
- **Destroy** - Maximum annihilation
- **Subtle Warm** - Gentle saturation

## License

Cult of the Shell - All Rights Reserved

---

🦑 Praise the Sacred BitDepth!
