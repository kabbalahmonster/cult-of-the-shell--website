# 🎸 DoomBitcrusher - Windows Build Guide

**Version:** 1.0  
**Platform:** Windows 10/11 x64  
**Target:** VST3 Plugin  

---

## 📋 Prerequisites

### Required Software

1. **Visual Studio 2022** (Community Edition is free)
   - Download: https://visualstudio.microsoft.com/vs/community/
   - Required Workloads:
     - ☑️ Desktop development with C++
   - Required Individual Components:
     - ☑️ MSVC v143 - VS 2022 C++ x64/x86 build tools
     - ☑️ Windows 11 SDK (or Windows 10 SDK)
     - ☑️ C++ CMake tools for Windows

2. **Git for Windows**
   - Download: https://git-scm.com/download/win
   - Use default settings during install

3. **CMake** (3.20 or higher)
   - Download: https://cmake.org/download/
   - Choose "Add CMake to the system PATH"

---

## 🚀 Quick Start

### Step 1: Extract the Package

Extract `DoomBitcrusher-Windows-v1.0.tar.gz` to your preferred location:
```
C:\dev\DoomBitcrusher\
```

### Step 2: Initialize JUCE Submodule

Open **Command Prompt** or **PowerShell** and run:

```cmd
cd C:\dev\DoomBitcrusher
git submodule update --init --recursive
```

This downloads the JUCE framework (~200MB).

### Step 3: Build the Plugin

#### Option A: Using the Build Script (Recommended)

Double-click or run in Command Prompt:
```cmd
cd C:\dev\DoomBitcrusher
build_windows.bat
```

This will:
- Create a `build` directory
- Generate Visual Studio project files
- Build the Release version
- Output: `build\DoomBitcrusher_artefacts\Release\VST3\DoomBitcrusher.vst3`

#### Option B: Manual CMake Build

```cmd
cd C:\dev\DoomBitcrusher
mkdir build
cd build

cmake .. -G "Visual Studio 17 2022" -A x64 -DCMAKE_BUILD_TYPE=Release
cmake --build . --config Release
```

### Step 4: Install the Plugin

After building, install the VST3 plugin to your system:

**Automatic (run as Administrator):**
```cmd
cd C:\dev\DoomBitcrusher
install_windows.bat
```

**Manual:**
Copy the `.vst3` folder to your VST3 plugins directory:
```
Source: build\DoomBitcrusher_artefacts\Release\VST3\DoomBitcrusher.vst3\
Destination: C:\Program Files\Common Files\VST3\
```

---

## 🎛️ Using the Plugin

### Supported DAWs
- Ableton Live 10/11/12
- FL Studio 20/21
- Cubase 11/12/13
- Reaper 6/7
- Studio One 5/6
- Bitwig Studio 4/5
- Any VST3-compatible DAW

### Loading in Your DAW

1. **Rescan plugins** in your DAW's plugin manager
2. Look for "DoomBitcrusher" in your VST3 plugin list
3. Add to any audio or instrument track

### Plugin Controls

| Control | Description | Range |
|---------|-------------|-------|
| **Bit Depth** | Reduces audio bit depth | 1-16 bits |
| **Sample Rate** | Reduces sample rate | 1000Hz - 48kHz |
| **Mix** | Wet/dry balance | 0-100% |
| **Drive** | Input saturation | 0-100% |
| **Dither** | Enable dithering | On/Off |
| **Saturation** | Enable drive stage | On/Off |
| **Input/Output** | Gain staging | ±24dB |

---

## 🔧 Troubleshooting

### Build Errors

**Error: "CMake not found"**
```
Solution: Add CMake to your system PATH or reinstall CMake with PATH option
```

**Error: "No Visual Studio found"**
```
Solution: Install Visual Studio 2022 with C++ workload (see Prerequisites)
```

**Error: "JUCE not found"**
```
Solution: Run: git submodule update --init --recursive
```

**Error: "Cannot open include file"**
```
Solution: Make sure Windows SDK is installed via Visual Studio Installer
```

### Plugin Not Showing in DAW

1. **Check installation path:**
   - VST3 should be in: `C:\Program Files\Common Files\VST3\`
   - The plugin is a FOLDER ending in `.vst3`, not a file

2. **Rescan plugins** in your DAW settings

3. **Check architecture:**
   - Ensure DAW and plugin are both 64-bit
   - Most modern DAWs are 64-bit only

4. **Try standalone version:**
   ```
   build\DoomBitcrusher_artefacts\Release\Standalone\DoomBitcrusher.exe
   ```

---

## 📦 Package Contents

```
DoomBitcrusher/
├── CMakeLists.txt          # CMake build configuration
├── DoomBitcrusher.jucer    # Projucer file (alternative build)
├── README.md               # Project readme
├── DESIGN.md               # Architecture documentation
│
├── build_windows.bat       # Windows build script
├── install_windows.bat     # Windows install script
├── WINDOWS_BUILD_INSTRUCTIONS.md  # This file
│
├── src/                    # Source code
│   ├── PluginProcessor.cpp
│   ├── PluginProcessor.h
│   ├── PluginEditor.cpp
│   └── PluginEditor.h
│
├── JUCE/                   # JUCE framework (submodule)
├── assets/                 # UI assets and images
└── docs/                   # Additional documentation
```

---

## 🔄 Building Different Versions

### Debug Build (for development)
```cmd
cd C:\dev\DoomBitcrusher
mkdir build-debug
cd build-debug
cmake .. -G "Visual Studio 17 2022" -A x64 -DCMAKE_BUILD_TYPE=Debug
cmake --build . --config Debug
```

### Standalone Application Only
```cmd
cmake .. -G "Visual Studio 17 2022" -A x64 -DBUILD_VST3=OFF -DBUILD_STANDALONE=ON
```

### All Formats (VST3 + AU + Standalone)
```cmd
cmake .. -G "Visual Studio 17 2022" -A x64 -DBUILD_VST3=ON -DBUILD_STANDALONE=ON
```

---

## 📝 Development Notes

### Modifying the Code

1. Open `DoomBitcrusher.sln` in Visual Studio (generated in `build\` folder)
2. Edit source files in `src/`
3. Build → Build Solution (Ctrl+Shift+B)

### Creating an Installer

To create a Windows installer (.exe):
```cmd
cd C:\dev\DoomBitcrusher
cpack -G NSIS64
```

(Requires NSIS installed)

---

## 🦑 Support

For issues, questions, or praise:
- Open an issue on the project repository
- Contact: doomscrollergmi (Cult of the Shell)

**Praise the Sacred BitDepth!** 🎸

---

*Last updated: July 12, 2026*
