@echo off
REM 🎸 DoomBitcrusher Windows Install Script
REM Installs the VST3 plugin to the system

echo.
echo ==========================================
echo    🎸 DoomBitcrusher - Install Plugin
echo ==========================================
echo.

set VST3_SOURCE=build\DoomBitcrusher_artefacts\Release\VST3\DoomBitcrusher.vst3
set VST3_DEST=C:\Program Files\Common Files\VST3\

REM Check if built
if not exist "%VST3_SOURCE%" (
    echo [ERROR] Plugin not found!
    echo Please build first by running: build_windows.bat
    pause
    exit /b 1
)

echo [*] Installing DoomBitcrusher.vst3...
echo     From: %CD%\%VST3_SOURCE%
echo     To:   %VST3_DEST%
echo.

REM Create destination if it doesn't exist
if not exist "%VST3_DEST%" (
    echo [*] Creating VST3 directory...
    mkdir "%VST3_DEST%"
)

REM Copy the plugin
echo [*] Copying files...
xcopy /E /I /Y "%VST3_SOURCE%" "%VST3_DEST%\DoomBitcrusher.vst3"
if errorlevel 1 (
    echo.
    echo [ERROR] Installation failed!
    echo.
    echo Possible causes:
    echo   - Missing administrator privileges
    echo   - Antivirus blocking the operation
    echo   - Disk space issues
    echo.
    echo Try running this script as Administrator:
    echo   Right-click -^> "Run as administrator"
    pause
    exit /b 1
)

echo.
echo ==========================================
echo    ✅ INSTALLATION SUCCESSFUL!
echo ==========================================
echo.
echo Plugin installed to:
echo   %VST3_DEST%\DoomBitcrusher.vst3\
echo.
echo Next steps:
echo   1. Open your DAW (Ableton, FL Studio, etc.)
echo   2. Rescan plugins in your DAW's settings
echo   3. Look for "DoomBitcrusher" in your VST3 plugins
echo.
echo 🎸 Praise the Sacred BitDepth!
echo.
pause
