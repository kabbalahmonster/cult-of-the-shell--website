@echo off
REM 🎸 DoomBitcrusher Windows Build Script
REM Builds the VST3 plugin using CMake and Visual Studio 2022

echo.
echo ==========================================
echo    🎸 DoomBitcrusher - Windows Build
echo ==========================================
echo.

REM Check if JUCE submodule is initialized
if not exist "JUCE\CMakeLists.txt" (
    echo [!] JUCE not found. Initializing submodule...
    git submodule update --init --recursive
    if errorlevel 1 (
        echo [ERROR] Failed to initialize JUCE submodule.
        echo Make sure git is installed: https://git-scm.com/download/win
        pause
        exit /b 1
    )
    echo [OK] JUCE initialized.
    echo.
)

REM Check for CMake
where cmake >nul 2>nul
if errorlevel 1 (
    echo [ERROR] CMake not found in PATH.
    echo Please install CMake: https://cmake.org/download/
    echo Make sure to select "Add CMake to the system PATH"
    pause
    exit /b 1
)
echo [OK] CMake found.

REM Check for Visual Studio
where cl >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Visual Studio 2022 compiler not found.
    echo Please run this script from "Developer Command Prompt for VS 2022"
    echo OR make sure Visual Studio 2022 with C++ workload is installed.
    pause
    exit /b 1
)
echo [OK] Visual Studio compiler found.

REM Create build directory
echo.
echo [*] Creating build directory...
if not exist build mkdir build
cd build

REM Generate project files
echo [*] Generating Visual Studio project files...
cmake .. -G "Visual Studio 17 2022" -A x64 -DCMAKE_BUILD_TYPE=Release
if errorlevel 1 (
    echo [ERROR] CMake configuration failed.
    cd ..
    pause
    exit /b 1
)

REM Build the project
echo [*] Building Release version...
echo     This may take a few minutes...
cmake --build . --config Release
if errorlevel 1 (
    echo [ERROR] Build failed.
    cd ..
    pause
    exit /b 1
)

echo.
echo ==========================================
echo    ✅ BUILD SUCCESSFUL!
echo ==========================================
echo.
echo Output location:
echo   VST3 Plugin: build\DoomBitcrusher_artefacts\Release\VST3\DoomBitcrusher.vst3\
echo   Standalone:  build\DoomBitcrusher_artefacts\Release\Standalone\DoomBitcrusher.exe
echo.
echo Next steps:
echo   1. Run install_windows.bat to install the plugin
echo   2. Or manually copy the .vst3 folder to:
echo      C:\Program Files\Common Files\VST3\
echo.
cd ..
pause
